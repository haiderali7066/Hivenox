import { Hero } from '@/components/home/hero'
import { Trusted } from '@/components/home/trusted'
import { AiWorkers } from '@/components/home/ai-workers'
import { ProductsShowcase } from '@/components/home/products-showcase'
import { WhyHivenox } from '@/components/home/why-hivenox'
import { Workflow } from '@/components/home/workflow'
import { Industries } from '@/components/home/industries'
import { IntegrationsSection } from '@/components/home/integrations-section'
import { Testimonials } from '@/components/home/testimonials'
import { PricingPreview } from '@/components/home/pricing-preview'
import { Insights } from '@/components/home/insights'
import { CtaBanner } from '@/components/cta-banner'

export default function HomePage() {
  return (
    <>
      <Hero />
      <Trusted />
      <AiWorkers />
      <ProductsShowcase />
      <WhyHivenox />
      <Workflow />
      <Industries />
      <IntegrationsSection />
      <Testimonials />
      <PricingPreview />
      <Insights />
      <CtaBanner />
    </>
  )
}
